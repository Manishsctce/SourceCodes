# spring-aop-logging
How to centralize logging mechanism using spring aop
